import tweepy
#import facebook
import nltk
from newspaper import Article 
from nltk import sent_tokenize
from nltk.sentiment.vader import SentimentIntensityAnalyzer
from tweepy import Stream
from tweepy import OAuthHandler
import string
import re
import unidecode
import csv
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import pandas as pd
import matplotlib.ticker as ticker
from sklearn.preprocessing import normalize

"Twitter tweets"

ckey="csT2g4e0epJeXRVZLOdUkvoEJ"
csecret="MDdRi4aEaGseS5LWKjXibEhlA8TSo8rRBpaRfEiK1XbAoQpKtP"
atoken="1078975381-9UnQG5AJ2TDyTkXBe2K26gQUtGYaOwbc6C9UYrA"
asecret="clVpdyZobr0lDSzxNLiWKgqB0OLGEMPvvVxi2bqovM9d3"


auth = OAuthHandler(ckey, csecret)
auth.set_access_token(atoken, asecret)
api = tweepy.API(auth)
sid = SentimentIntensityAnalyzer()


def max_dict(count):
    maxi= 0
    max_key=0
    for i in count.keys():
        if (count[i]>maxi):
            maxi= count[i]
            max_key=i
    return(max_key)

def collect_tweets():
    ques= [['BJP','Modi'], ['Congress', 'Rahul Gandhi'], ['BSP', 'samajwadi party', 'mayawati']]
    dict1= {}
    for p in ques:
        tweet_counter=0
        dict1[p[0]]=[]
        for t in p:
            for tweet_info in tweepy.Cursor(api.search, q='place:b850c1bfd38f30e0 '+t, lang = 'en', result_type='recent', tweet_mode='extended').items(100):
                tweet_counter+=1
                if 'retweeted_status' in dir(tweet_info):
                    u=tweet_info.retweeted_status.full_text
                    d=tweet_info.user.id_str
                    #print(tweet_info.user.id)

                else:
                    u=tweet_info.full_text
                    d=tweet_info.user.id_str
                    #print(tweet_info.user.id)

                u=u.encode('unicode-escape').decode('utf-8')
                u = re.sub(r'https?:\/\/.*[\r\n]*', '', u)
                u = re.sub(r'#', '', u)
                u = re.sub(r'@', '', u)
                u = re.sub(r'\\n', '', u)
                u = re.sub(r'\\u....', '', u)
                u = re.sub(r'\\U0001....', '', u)
                u = re.sub(r'&gt;', '', u)
                u = re.sub(r'&amp;','',u)
                u = re.sub(r'\\xa0', ' ', u)
                #print(str(tweet_counter)+ ". Tweet text: "+ u)
                dict1[p[0]].append([u,d])

    for key in dict1.keys():
        dict2={}
        filen= key + ".csv"
        list1= list(dict1[key])
        #print(list1)
        for sentence in list1:
            ss = sid.polarity_scores(sentence[0])
        #print(ss["compound"])
            dict2[sentence[0]]= [ss["compound"],sentence[1]]
            """
        with open(filen, 'a+') as csv_file:
            writer = csv.writer(csv_file)
            for key, value in dict2.items():
                writer.writerow([key, value])
        """
        pd.DataFrame(dict2).T.reset_index().to_csv(filen, mode='a' , header=False, index=False)

def clustering():
    files= ['BJP.csv', 'BSP.csv', 'Congress.csv']
   # cols=['tweet','sentiment','user']
    dfs=[]
    sups=[]
    pos=[]
    negs=[]
    for i in files:
        data = pd.read_csv(i)
        data.columns = ['tweet','sentiment','user']
        dfs.append(data)
        #print(data)
        #print(data.ix[:,2])
        sups.append(list(set(list(data['user']))))
        pos.append(list(set(list(data.loc[data['sentiment']>0, 'user']))))
        negs.append(list(set(list(data.loc[data['sentiment']<0, 'user']))))
        p = list(set(list(data.loc[data['sentiment']>0, 'user'])))
        n = list(set(list(data.loc[data['sentiment']<0, 'user'])))
        count={}
        for k in p:
            c= data.loc[data['user']== k].shape[0]
            count[k]=c
        print("The user with maximum number of positive tweets about "+ (i.split('.'))[0] + " is: ")
        mc=max_dict(count)
        print(mc)
        print(api.get_user(int(mc)).name)
        print()
        #print(count)

    
    l1, = plt.plot(list(dfs[0].loc[(dfs[0])['sentiment']>0, 'sentiment']),'r*')
    l2, = plt.plot(list(dfs[1].loc[(dfs[1])['sentiment']>0, 'sentiment']), 'g+')
    l3, = plt.plot(list(dfs[2].loc[(dfs[2])['sentiment']>0, 'sentiment']), 'b^')
    plt.legend(['BJP', 'BSP','Congress'])
    plt.title("Clusters of people in support of the three parties")
    plt.show()
    l1, = plt.plot(list(dfs[0].loc[(dfs[0])['sentiment']<0, 'sentiment']),'r*')
    l2, = plt.plot(list(dfs[1].loc[(dfs[1])['sentiment']<0, 'sentiment']), 'g+')
    l3, = plt.plot(list(dfs[2].loc[(dfs[2])['sentiment']<0, 'sentiment']), 'b^')
    plt.legend(['BJP', 'BSP','Congress'])
    plt.title("Clusters of people who critisize the three parties")
    plt.show()


    
clustering()
#collect_tweets()
