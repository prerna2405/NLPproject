import tweepy
#import facebook
import nltk
from newspaper import Article 
from nltk import sent_tokenize
from nltk.sentiment.vader import SentimentIntensityAnalyzer
from tweepy import Stream
from tweepy import OAuthHandler
import string
import re
import unidecode
import csv
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import matplotlib.ticker as ticker

"Twitter tweets"

ckey="csT2g4e0epJeXRVZLOdUkvoEJ"
csecret="MDdRi4aEaGseS5LWKjXibEhlA8TSo8rRBpaRfEiK1XbAoQpKtP"
atoken="1078975381-9UnQG5AJ2TDyTkXBe2K26gQUtGYaOwbc6C9UYrA"
asecret="clVpdyZobr0lDSzxNLiWKgqB0OLGEMPvvVxi2bqovM9d3"


auth = OAuthHandler(ckey, csecret)
auth.set_access_token(atoken, asecret)
api = tweepy.API(auth)
sid = SentimentIntensityAnalyzer()

def collect_tweets():
    ques= [['BJP','Modi'], ['Congress', 'Rahul Gandhi'], ['BSP', 'samajwadi party', 'mayawati']]
    dict1= {}
    for p in ques:
        tweet_counter=0
        dict1[p[0]]=[]
        for t in p:
            for tweet_info in tweepy.Cursor(api.search, q='place:b850c1bfd38f30e0 '+t, lang = 'en', result_type='recent', tweet_mode='extended').items(50):
                tweet_counter+=1
                if 'retweeted_status' in dir(tweet_info):
                    u=tweet_info.retweeted_status.full_text                    

                else:
                    u=tweet_info.full_text

                u=u.encode('unicode-escape').decode('utf-8')
                u = re.sub(r'https?:\/\/.*[\r\n]*', '', u)
                u = re.sub(r'#', '', u)
                u = re.sub(r'@', '', u)
                u = re.sub(r'\\n', '', u)
                u = re.sub(r'\\u....', '', u)
                u = re.sub(r'\\U0001....', '', u)
                u = re.sub(r'&gt;', '', u)
                u = re.sub(r'&amp;','',u)
                u = re.sub(r'\\xa0', ' ', u)
                #print(str(tweet_counter)+ ". Tweet text: "+ u)
                dict1[p[0]].append(u)


    for key in dict1.keys():
        dict2={}
        filen= key + ".csv"
        list1= list(dict1[key])
        for sentence in list1:
            ss = sid.polarity_scores(sentence)
            dict2[sentence]= ss["compound"]

        with open(filen, 'a+') as csv_file:
            writer = csv.writer(csv_file)
            for key, value in dict2.items():
                writer.writerow([key, value])



def collect_news():
    #urls= ["https://timesofindia.indiatimes.com/city/shimla/bjp-eyes-dalit-vote-bank-mobilisation-events-begin/articleshow/68489525.cms", "https://timesofindia.indiatimes.com/india/after-state-poll-rout-bjp-drops-all-10-mps-in-chhattisgarh/articleshow/68490009.cms","https://timesofindia.indiatimes.com/india/if-you-want-your-child-to-become-chowkidar-vote-for-modi-kejriwal/articleshow/68494536.cms", "https://timesofindia.indiatimes.com/india/i-will-not-contest-lok-sabha-elections-bsp-chief-mayawati/articleshow/68495057.cms", "https://timesofindia.indiatimes.com/india/cong-releases-sixth-list-of-candidates/articleshow/68491765.cms", "https://timesofindia.indiatimes.com/india/india-may-not-have-elections-if-modi-re-elected-may-go-china-way-ashok-gehlot/articleshow/68479408.cms"]
    #urls= ["https://timesofindia.indiatimes.com/city/visakhapatnam/womens-constituency-is-divided-on-poll-issues/articleshow/68514496.cms", "https://timesofindia.indiatimes.com/india/satta-bazaar-in-madhya-pradesh-bets-on-bjp-getting-246-seats/articleshow/68510139.cms", "https://timesofindia.indiatimes.com/india/priyanka-calls-elections-indias-new-freedom-struggle/articleshow/68503102.cms", "https://timesofindia.indiatimes.com/india/bjp-releases-first-list-for-lok-sabha-polls-5-key-takeaways/articleshow/68514290.cms", "https://timesofindia.indiatimes.com/politics/news/ls-poll-vaithilingam-congress-candidate-for-puducherry-ls-seat/articleshow/68516965.cms"]
    urls= ["https://timesofindia.indiatimes.com/india/advani-bjps-tallest-leader-shiv-sena/articleshow/68533543.cms", "https://timesofindia.indiatimes.com/city/mumbai/lok-sabha-elections-rss-urges-voters-to-go-in-for-nota-bandi/articleshow/68532088.cms"]
    for i in urls:
        url = i
        toi_article = Article(url, language="en") # en for English
        toi_article.download()
        toi_article.parse()
        toi_article.nlp()
        #print("Article's Text:")
        #print(toi_article.text)
        #print("\n")
        #print(sent_tokenize(toi_article.text))
        sents= sent_tokenize(toi_article.text)
        for i in sents:
            i = i.encode('unicode-escape').decode('utf-8')
            i = re.sub(r'https?:\/\/.*[\r\n]*', '', i)
            i = re.sub(r'#', '', i)
            i = re.sub(r'@', '', i)
            i = re.sub(r'\\n', '', i)
            i = re.sub(r'\\u....', '', i)
            if "BJP" in i or "Modi" in i or "PM" in i:
                ss = sid.polarity_scores(i)
                #print(i+ str(ss['compound']))
                with open("BJP.csv", 'a+') as csv_file:
                    writer = csv.writer(csv_file)
                    writer.writerow([i, ss['compound']])
            if "Congress" in i or "Rahul" in i or "Rahul Gandhi" in i:
                ss = sid.polarity_scores(i)
                #print(i+ str(ss['compound']))
                with open("Congress.csv", 'a+') as csv_file:
                    writer = csv.writer(csv_file)
                    writer.writerow([i, ss['compound']])
            if "BSP" in i or "samajwadi" in i:
                ss = sid.polarity_scores(i)
                #print(i+ str(ss['compound']))
                with open("BSP.csv", 'a+') as csv_file:
                    writer = csv.writer(csv_file)
                    writer.writerow([i, ss['compound']])



#collect_tweets()
#collect_news()

def visualize():
    with open('BJP.csv') as csv_file:
        reader = csv.reader(csv_file)
        BJP = dict(reader)
        #print(len(BJP))
        #print((list(BJP.items()))[0:4])

    bjpl=[float(i) for i in BJP.values()]
    avg_bjp=0
    bjpi=[]
    k=1
    for i in BJP.values():
        avg_bjp+= float(i)
        bjpi.append(k)
        k+=1
    
    with open('Congress.csv') as csv_file:
        reader = csv.reader(csv_file)
        Cong = dict(reader)

    congl=[float(i) for i in Cong.values()]
    avg_cong=0
    congi=[]
    k=1
    for i in Cong.values():
        avg_cong+= float(i)
        congi.append(k)
        k+=1
   
    with open('BSP.csv') as csv_file:
        reader = csv.reader(csv_file)
        BSP = dict(reader)

    bspl=[float(i) for i in BSP.values()]
    avg_bsp=0
    bspi=[]
    k=1
    for i in BSP.values():
        avg_bsp+= float(i)
        bspi.append(k)
        k+=1
    
    den= max([len(BJP), len(Cong), len(BSP)])
    avg_bjp /= den
    print(avg_bjp)
    avg_cong /= den
    print(avg_cong)
    avg_bsp /= den
    print(avg_bsp)
    plt.bar(['BJP','Congress', 'BSP'], [avg_bjp,avg_cong, avg_bsp], color=['red', 'green', 'blue'])
    plt.ylabel('Average compound sentiment value')
    plt.xlabel('Major parties in all the fronts')
    plt.show()
    plt.plot(bjpl, 'r')
    plt.ylabel('Compound sentiment value')
    plt.title('BJP - compound sentiment value analysis')
    plt.show()
    plt.plot(congl, 'g')
    plt.ylabel('Compound sentiment value')
    plt.title('Congress - compound sentiment value analysis')
    plt.show()
    plt.plot(bspl, 'b')
    plt.ylabel('Compound sentiment value')
    plt.title('BSP - compound sentiment value analysis')
    plt.show()
    l1, = plt.plot(bjpl,'r*')
    l2, = plt.plot(congl, 'g+')
    l3, = plt.plot(bspl, 'b^')
    plt.legend(['BJP','Congress', 'BSP'])
    plt.show()
    

visualize()
